# Neural Network Compression Examples

There are many official examples in DNN compression in NNabla. This directory is a proxy for synonym, see the [reductin](https://github.com/sony/nnabla-examples/tree/master/reduction) in running examples.

